package com.infy.util;

public class CartException extends Exception {
	public CartException(String msg) {
		super(msg);
	}
}
