package com.infy.util;

public class OrderDetailsException extends Exception {
	public OrderDetailsException(String msg){
		super(msg);
	}
}
