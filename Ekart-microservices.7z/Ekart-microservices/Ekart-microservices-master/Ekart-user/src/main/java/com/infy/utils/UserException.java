package com.infy.utils;

public class UserException extends Exception {
	public UserException(String msg){
		super(msg);
	}
}
