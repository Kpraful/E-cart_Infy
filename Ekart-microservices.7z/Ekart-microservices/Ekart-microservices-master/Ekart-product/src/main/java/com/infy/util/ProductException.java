package com.infy.util;

public class ProductException extends Exception {
	public ProductException(String msg) {
		super(msg);
	}
}
