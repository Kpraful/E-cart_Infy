package com.infy.utils;

public class RatingsException extends Exception {
	public RatingsException(String msg) {
		super(msg);
	}
}
