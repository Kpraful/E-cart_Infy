package com.infy.util;

public class DealsException extends Exception {
	public DealsException(String msg){
		super(msg);
	}
}
